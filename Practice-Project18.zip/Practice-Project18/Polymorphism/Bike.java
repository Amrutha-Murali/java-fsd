class Bike{  
  void run(){System.out.println("running");}  
}  
