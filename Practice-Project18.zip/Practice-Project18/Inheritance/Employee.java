class Employee{  
 float salary=40000;  
}  
