// Class 2
// Main class
class Seventh2 {

	// Main driver method
	public static void main(String[] args)
	{

		// Note how inner class object is created inside
		// main()
		Seventh.Inner in = new Seventh().new Inner();

		// Calling show() method over above object created
		in.show();
	}
}
