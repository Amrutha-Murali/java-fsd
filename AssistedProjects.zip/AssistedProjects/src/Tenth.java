// Java Program Demonstrating Working of matches() Method
// Pattern class

// Importing Pattern class from java.util.regex package
import java.util.regex.Pattern;

// Main class
class Tenth {

	// Main driver method
	public static void main(String args[])
	{

		// Following line prints "true" because the whole
		// text "geeksforgeeks" matches pattern
		// "geeksforge*ks"
		System.out.println(Pattern.matches(
			"geeksforge*ks", "geeksforgeeks"));

		// Following line prints "false" because the whole
		// text "geeksfor" doesn't match pattern "g*geeks*"
		System.out.println(
			Pattern.matches("g*geeks*", "geeksfor"));
	}
}

