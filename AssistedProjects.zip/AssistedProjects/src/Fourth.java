public class Fourth{
  private String name;

  // constructor
  Fourth() {
    System.out.println("Constructor Called:");
    name = "Amrutha";
  }

  public static void main(String[] args) {

    // constructor is invoked while
    // creating an object of the Main class
    Fourth obj = new Fourth();
    System.out.print("The name is " + obj.name);
  }
 }
  