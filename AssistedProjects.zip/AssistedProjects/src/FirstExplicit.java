// Java program to Illustrate Explicit Type Conversion

// Main class
public class FirstExplicit {

	// Main driver method
	public static void main(String[] args)
	{

		// Double data type
		double d = 100.04;

		// Explicit type casting by forcefully getting
		// data from long data type to integer type
		long l = (long)d;

		// Explicit type casting
		int i = (int)l;

		// Print statements
		System.out.println("Double value " + d);

		// While printing we will see that
		// fractional part lost
		System.out.println("Long value " + l);

		// While printing we will see that
		// fractional part lost
		System.out.println("Int value " + i);
	}
}
