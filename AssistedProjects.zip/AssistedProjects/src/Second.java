class Second {
    private String name;

    // getter method
    public String getName() {
        return this.name;
    }
    // setter method
    public void setName(String name) {
        this.name= name;
    }
    
    public static void main(String[] main){
    	Second d = new Second();

        // access the private variable using the getter and setter
        d.setName("Access Modifiers");
        System.out.println(d.getName());
    }
}