class ThreadClass extends Thread {
	public void run()
	{
		System.out.print("Welcome to my world.");
	}
	public static void main(String[] args)
	{
		ThreadClass g = new ThreadClass(); // creating thread
		g.start(); // starting thread
	}
}