import java.io.FileWriter;
import java.io.IOException;
public class Append {
public static void main(String[] args)
{
String data = "This data is appended..";
try {
FileWriter output = new FileWriter("amrutha1.txt", true);
output.write(data);
System.out.println("Data appended successfully.");
output.close();
}catch (IOException ex) {
System.out.println("File append error..");
}
}
}